Thank you for sending your pull request. But first, have you included
unit tests, and is your code PEP8 conformant? [More details](https://github.com/freqtrade/freqtrade/blob/develop/CONTRIBUTING.md)

## Summary

Explain in one sentence the goal of this PR

Solve the issue: #___

## Quick changelog

- <change log 1>
- <change log 1>

## What's new?

*Explain in details what this PR solve or improve. You can include visuals.* 
