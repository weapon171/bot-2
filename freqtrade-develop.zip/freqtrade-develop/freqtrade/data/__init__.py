"""
Module to handle data operations for freqtrade
"""

# limit what's imported when using `from freqtrade.data import *`
__all__ = [
    'converter'
]
